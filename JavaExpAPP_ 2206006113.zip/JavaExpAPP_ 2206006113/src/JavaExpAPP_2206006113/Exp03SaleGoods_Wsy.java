package JavaExpAPP_2206006113;

import java.util.Scanner;

public class Exp03SaleGoods_Wsy extends Exp03Goods_Wsy {

    static int SaleCount_Wsy;
    public static  int[] num_Wsy;
    public static int[]  cont_Wsy;

    public static void main(String[] args) {

    }

    void InitSaleCount_Wsy(){
        System.out.println("现有以下种类和数量:");
        for (int i_Wsy = 0; i_Wsy < Exp03_Wsy.Goods_Wsy.length; i_Wsy++) {
            System.out.println("编号:"+Exp03_Wsy.Goods_Wsy[i_Wsy].GoodsNum_Wsy);
            System.out.println("名字:"+Exp03_Wsy.Goods_Wsy[i_Wsy].GoodsName_Wsy);
            System.out.println("数量:"+Exp03_Wsy.Goods_Wsy[i_Wsy].GoodsCount_Wsy);
            System.out.println("----------------------------------------");
        }
        System.out.println("请输入你想要卖多少种东西:");
        Scanner SX_Wsy=new Scanner(System.in);
        int c_Wsy=SX_Wsy.nextInt();

        SaleCount_Wsy=c_Wsy;
        num_Wsy=new int[c_Wsy];
        cont_Wsy=new int[c_Wsy];

        //初始化数组大小
        for (int i_Wsy = 0; i_Wsy < c_Wsy; i_Wsy++) {
            System.out.println("请输入你想要卖货物的编号:");
            Scanner Sc_Wsy = new Scanner(System.in);
            int n_Wsy=Sc_Wsy.nextInt();
            num_Wsy[i_Wsy] = n_Wsy;


            System.out.println("请输入售卖该货物的数量:");
            Scanner Sa_Wsy=new Scanner(System.in);
            int count_Wsy = Sa_Wsy.nextInt();
            cont_Wsy[i_Wsy]=count_Wsy;
        }

    }

    void ShowSaleNum() {
        int sum_Wsy=0;
        for (int i_Wsy = 0; i_Wsy < Exp03_Wsy.Goods_Wsy.length; i_Wsy++) {

            sum_Wsy+=Exp03_Wsy.Goods_Wsy[i_Wsy].GoodsCount_Wsy;
        }
            if (SaleCount_Wsy>sum_Wsy){
                System.out.println("输出失败，售货数量不能大于购货数量");
            }else {
                System.out.println("售货情况:");
                for (int i_Wsy = 0; i_Wsy < SaleCount_Wsy; i_Wsy++) {
                    if(cont_Wsy[i_Wsy]!=0) {
                        System.out.println("编号:"+num_Wsy[i_Wsy] + "名字:"+ Exp03_Wsy.Goods_Wsy[i_Wsy].GoodsName_Wsy+"售卖的数量:" + cont_Wsy[i_Wsy]);
                    }
                }
            }

    }


}
