package JavaExpAPP_2206006113;

import java.util.Scanner;

public class Exp05_Wsy {
    void  menu_Wsy(){
        while(true) {
            System.out.println("请选择你的项目:");
            System.out.println("0:退出选择");
            System.out.println("1:客车售票系统");
            System.out.println("2:数英翻译程序");
            System.out.println("3:字符串加密");
            Scanner SC_Wsy = new Scanner(System.in);
            int choice_Wsy = SC_Wsy.nextInt();
            switch (choice_Wsy) {
                case 0:
                    return;
                case 1:
                    ticket_Wsy();
                    break;

                case 2:
                    translate_Wsy();
                    break;

                case 3:
                    stringEncrypt_Wsy();
                    break;


            }
        }
    }
    void ticket_Wsy() {
        System.out.println("请输入客车的排数和列数:");
        Scanner SX_Wsy = new Scanner(System.in);
        System.out.println("排数:");
        int line_Wsy = SX_Wsy.nextInt();
        System.out.println("列数:");
        int cow_Wsy = SX_Wsy.nextInt();

        int[][] num_Wsy = new int[cow_Wsy + 1][line_Wsy + 1];


        for (int i_Wsy = 1; i_Wsy <= cow_Wsy; i_Wsy++) {
            for (int j_Wsy = 1; j_Wsy <= line_Wsy; j_Wsy++) {
                num_Wsy[i_Wsy][j_Wsy] = 0;
            }
        }

        while (true) {
            System.out.println("请选择:");
            System.out.println("0:退出买票系统");
            System.out.println("1:进入买票系统");
            Scanner SZ_Wsy = new Scanner(System.in);
            int choice_Wsy = SZ_Wsy.nextInt();
            switch (choice_Wsy) {
                case 0:
                    return;
                case 1:
                    while (true) {
                        System.out.println("请购买你想要的座位号");
                        System.out.println("排数");
                        int x_Wsy = SX_Wsy.nextInt();
                        System.out.println("列数");
                        int y_Wsy = SX_Wsy.nextInt();

                        if (num_Wsy[x_Wsy][y_Wsy] == 0) {
                            System.out.println("有票");
                            num_Wsy[x_Wsy][y_Wsy] = 1;
                        } else if (num_Wsy[x_Wsy][y_Wsy] == 1) {
                            System.out.println("已售");
                        }

                        System.out.println("你是否想继续购票:");
                        System.out.println("0:退出购票");
                        System.out.println("1:继续购票");
                        Scanner SA_Wsy = new Scanner(System.in);
                        int c_Wsy = SA_Wsy.nextInt();
                        if (c_Wsy == 0) {
                            break;
                        } else if (c_Wsy == 1) {
                            continue;
                        }
                    }
                    break;
            }
        }
    }

    void translate_Wsy() {
        while (true) {
            System.out.println("请选择:");
            System.out.println("0:退出选择");
            System.out.println("1:数字转英文");
            System.out.println("2:英文转数字");
            Scanner SX_Wsy=new Scanner(System.in);
            int c_Wsy=SX_Wsy.nextInt();

            String[] x_Wsy = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
            String[] y_Wsy = {"ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"};
            String[] z_Wsy = {"twenty", "thirty", "fourty", "fifty", "sixty", "seventy", "eighty", "ninety"};

            switch (c_Wsy) {
                case 0:
                    return;
                case 1:
                System.out.println("请输入一个小于100的整数:");
                Scanner SS_Wsy = new Scanner(System.in);
                int num_Wsy = SS_Wsy.nextInt();

                if (num_Wsy <= 9) {
                    System.out.println("该数字的英文:" + x_Wsy[num_Wsy]);
                } else if (num_Wsy >= 10 && num_Wsy <= 19) {
                    int rem_Wsy;
                    rem_Wsy = num_Wsy % 10;
                    System.out.println("该数字的英文:" + y_Wsy[rem_Wsy]);
                } else if (num_Wsy >= 20 && num_Wsy <= 99) {
                    int decade_Wsy;
                    int unit_Wsy;
                    decade_Wsy = num_Wsy / 10 - 2;
                    unit_Wsy = num_Wsy % 10;
                    System.out.println("该数字的英文:" + z_Wsy[decade_Wsy] + x_Wsy[unit_Wsy]);
                }

                break;
                case 2:
                    System.out.println("请输入一个小于100的整数的英文:");

                    Scanner SC_Wsy=new Scanner(System.in);
                    String eng_Wsy=SC_Wsy.nextLine();

                    //0-19
                    for (int i_Wsy = 0; i_Wsy < 10; i_Wsy++) {
                            if (eng_Wsy.equals(x_Wsy[i_Wsy])){
                                System.out.println("该英文的数字:"+i_Wsy);
                            } else if (eng_Wsy.equals(y_Wsy[i_Wsy])) {
                                System.out.println("该英文的数字:"+(10+i_Wsy));
                            }
                    }
                    //20-100
                    for (int a_Wsy = 0; a_Wsy < 8; a_Wsy++) {
                        for (int b_Wsy = 0; b_Wsy < 8; b_Wsy++) {
                            if(eng_Wsy.equals(z_Wsy[a_Wsy].concat(x_Wsy[b_Wsy]))){
                                System.out.println("该英文的 数字为:"+((a_Wsy+2)*10+b_Wsy));
                            }
                        }
                    }

                    break;
            }

        }
    }


    void stringEncrypt_Wsy() {
        System.out.println("请输入你的原始字符串:");

        Scanner SD_Wsy = new Scanner(System.in);
        String cc_Wsy = SD_Wsy.nextLine(); // 输入的字符串

        char[] c_Wsy = new char[cc_Wsy.length()]; // 加密后的字符数组

        System.out.println("请输入你的密钥:");
        int a_Wsy = SD_Wsy.nextInt();

        for (int i_Wsy = 0; i_Wsy < cc_Wsy.length(); i_Wsy++) {
            char temp_Wsy = cc_Wsy.charAt(i_Wsy);//取字符串

            if (temp_Wsy >= '0' && temp_Wsy <= '9') { // 处理数字
                c_Wsy[i_Wsy] = (char) ((temp_Wsy - '0' + a_Wsy) % 10 + '0');
            } else if (temp_Wsy >= 'a' && temp_Wsy <= 'z') { // 处理小写字母
                c_Wsy[i_Wsy] = (char) ((temp_Wsy - 'a' + a_Wsy) % 26 + 'a');
            } else if (temp_Wsy >= 'A' && temp_Wsy <= 'Z') { // 处理大写字母
                c_Wsy[i_Wsy] = (char) ((temp_Wsy - 'A' + a_Wsy) % 26 + 'A');
            } else { // 其他非数字、字母字符，保持不变
                c_Wsy[i_Wsy] = temp_Wsy;
            }
        }

        String aa_Wsy = new String(c_Wsy);
        System.out.println("加密后的字符串: " + aa_Wsy);
    }
}

