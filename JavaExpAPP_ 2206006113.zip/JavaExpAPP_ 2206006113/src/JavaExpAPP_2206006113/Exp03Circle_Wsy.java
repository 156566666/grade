package JavaExpAPP_2206006113;

import java.util.Scanner;

public class Exp03Circle_Wsy {
    static int radius_Wsy;
    static double P_Wsy;
    static double A_Wsy;

    public Exp03Circle_Wsy(){
        radius_Wsy=0;
    }
    public Exp03Circle_Wsy(int r_Wsy){
        radius_Wsy=r_Wsy;
    }

    public static void main(String[] args) {
    }

    void circleExec_Wsy(){
        System.out.println("请输入园的半径:");
        Scanner SS_Wsy=new Scanner(System.in);
        int r1_Wsy=SS_Wsy.nextInt();

        Exp03Circle_Wsy d_Wsy=new Exp03Circle_Wsy(1);

        d_Wsy.getRadius_Wsy(r1_Wsy);//初始化父类的半径
        d_Wsy.getArea_Wsy();//圆面积
        d_Wsy.getPerimeter_Wsy();//园周长


        Exp03Cylinder_2206006113 dd_Wsy=new Exp03Cylinder_2206006113(r1_Wsy,0);
        dd_Wsy.getHeight_Wsy();//圆柱体的高
        dd_Wsy.getCylinderArea_Wsy();//圆柱体的面积
        dd_Wsy.getVol_Wsy();//圆柱体的体积

        dd_Wsy.show_Wsy();
    }


    int getRadius_Wsy(int rr_Wsy){
        radius_Wsy=rr_Wsy;
        return  radius_Wsy;
    }

    double getPerimeter_Wsy(){
        P_Wsy=2*Math.PI*radius_Wsy;
        return  P_Wsy;
    }

    double getArea_Wsy(){
        A_Wsy=Math.PI*radius_Wsy*radius_Wsy;
        return A_Wsy;
    }

}


class Exp03Cylinder_2206006113 extends Exp03Circle_Wsy{
    static int h_Wsy;
    static double area_Wsy;
    static double vol_Wsy;
    public Exp03Cylinder_2206006113(int r_Wsy,int h_Wsy ){
        super(r_Wsy);

        this.h_Wsy=h_Wsy;
    }

    int getHeight_Wsy(){
        System.out.println("请输入圆柱体的高:");
        Scanner SX=new Scanner(System.in);
        int h_Wsy= SX.nextInt();
        this.h_Wsy=h_Wsy;
        return this.h_Wsy;
    }
    double getCylinderArea_Wsy(){
        area_Wsy=2*radius_Wsy*radius_Wsy*Math.PI+2*Math.PI*radius_Wsy*h_Wsy;
        return  area_Wsy;
    }
    double getVol_Wsy(){

        vol_Wsy=Math.PI*radius_Wsy*radius_Wsy*h_Wsy;
        return  vol_Wsy;
    }

    void show_Wsy(){
        System.out.println("园的半径是:"+radius_Wsy);
        System.out.println("圆柱体的半径是:"+radius_Wsy);
        System.out.println("圆柱体的高是 :"+h_Wsy);
        System.out.println("园的周长是:"+P_Wsy);
        System.out.println("园的面积是:"+A_Wsy);
        System.out.println("圆柱体的面积"+area_Wsy);
        System.out.println("圆柱体的体积"+vol_Wsy);
    }
}
