package JavaExpAPP_2206006113;

import java.util.Scanner;

public class Exp03ScoreManage_Wsy {//初始化数据和用方法scoreManageExec,调用2中各个类的成员方法，被menu调用以及其他方法
    static Exp02Score_Wsy.Exp02Teacher_Wsy[] teaS_Wsy=new Exp02Score_Wsy.Exp02Teacher_Wsy[]{
            new Exp02Score_Wsy.Exp02Teacher_Wsy(1,"田魁园"),
            new Exp02Score_Wsy.Exp02Teacher_Wsy(2,"周正娟"),
            new Exp02Score_Wsy.Exp02Teacher_Wsy(3,"张启军")
    };

    static Exp02Score_Wsy.Exp02Student_Wsy[] stuS_Wsy=new Exp02Score_Wsy.Exp02Student_Wsy[]{
            new Exp02Score_Wsy.Exp02Student_Wsy(105,"李鑫晨"),
            new Exp02Score_Wsy.Exp02Student_Wsy(117,"赵永江"),
            new Exp02Score_Wsy.Exp02Student_Wsy(122,"胡越超"),
            new Exp02Score_Wsy.Exp02Student_Wsy(128,"段锐"),
            new Exp02Score_Wsy.Exp02Student_Wsy(129,"李帛恒")
    };

    static Exp02Score_Wsy.Exp02Course_Wsy[] courS_Wsy=new Exp02Score_Wsy.Exp02Course_Wsy[]{
            new Exp02Score_Wsy.Exp02Course_Wsy(11,"计算机网络"),
            new Exp02Score_Wsy.Exp02Course_Wsy(22,"操作系统"),
            new Exp02Score_Wsy.Exp02Course_Wsy(33,"Java")
    };

    static Exp02Score_Wsy scoS_Wsy[]=new Exp02Score_Wsy[]{
            new Exp02Score_Wsy("周正娟","胡越超","计算机网络",0),
            new Exp02Score_Wsy("周正娟","李鑫晨","计算机网络",0),
            new Exp02Score_Wsy("周正娟","赵永江","计算机网络",0),
            new Exp02Score_Wsy("周正娟","李帛恒","计算机网络",0),
            new Exp02Score_Wsy("周正娟","段锐","计算机网络",0),
            new Exp02Score_Wsy("张启军","胡越超","Java",0),
            new Exp02Score_Wsy("张启军","李鑫晨","Java",0),
            new Exp02Score_Wsy("张启军","赵永江","Java",0),
            new Exp02Score_Wsy("张启军","李帛恒","Java",0),
            new Exp02Score_Wsy("张启军","段锐","Java",0),
            new Exp02Score_Wsy("田魁园","胡越超","操作系统",0),
            new Exp02Score_Wsy("田魁园","李鑫晨","操作系统",0),
            new Exp02Score_Wsy("田魁园","赵永江","操作系统",0),
            new Exp02Score_Wsy("田魁园","李帛恒","操作系统",0),
            new Exp02Score_Wsy("田魁园","段锐","操作系统",0)
    };

    public static void main(String[] args) {
    }

    static public void scoreManageExec_Wsy(){
        while (true) {
            System.out.println("请选择你想登录的客户端:");
            System.out.println("0:退出系统");
            System.out.println("1:教师端");
            System.out.println("2:学生端");
            Scanner cc_Wsy=new Scanner(System.in);
            int Cho_Wsy=cc_Wsy.nextInt();
            switch (Cho_Wsy) {
                case 0:
                    return ;
                case 1:
                System.out.println("请老师输入自己编号登录系统 :");
                Scanner S_Wsy = new Scanner(System.in);
                int S1_Wsy = S_Wsy.nextInt();
                if ((S1_Wsy == teaS_Wsy[0].teacherId_Wsy) || (S1_Wsy == teaS_Wsy[1].teacherId_Wsy) || (S1_Wsy == teaS_Wsy[2].teacherId_Wsy)) {
                    System.out.println("ID正确，登陆成功");
                    while (true) {
                        System.out.println("请输入你想完成的操作：");
                        System.out.println("0:退出系统");
                        System.out.println("1:录入");
                        System.out.println("2:显示");
                        System.out.println("3:查询");
                        System.out.println("4:修改");
                        System.out.println("5:统计");
                        Scanner c_Wsy = new Scanner(System.in);
                        int Choice_Wsy = c_Wsy.nextInt();
                        switch (Choice_Wsy) {
                            case 0:
                                return;
                            case 1:
                                luru_Wsy();
                                break;
                            case 2:
                                xianshi_Wsy();
                                break;
                            case 3:
                                chaxun_Wsy();
                                break;
                            case 4:
                                xiugai_Wsy();
                                break;
                            case 5:
                                tongji_Wsy();
                                break;
                        }

                    }
                }
                break;

                case 2:
                    System.out.println("请学生输入自己编号登录系统 :");
                    Scanner SS_Wsy = new Scanner(System.in);
                    int S2_Wsy = SS_Wsy.nextInt();
                if ((S2_Wsy == stuS_Wsy[0].studentID_Wsy) || (S2_Wsy == stuS_Wsy[1].studentID_Wsy) || (S2_Wsy == stuS_Wsy[2].studentID_Wsy) || (S2_Wsy == stuS_Wsy[3].studentID_Wsy) || (S2_Wsy == stuS_Wsy[4].studentID_Wsy)) {
                    System.out.println("学生ID正确，登录成功");
                    for (int i = 0; i < 5; i++) {
                        if (S2_Wsy == stuS_Wsy[i].studentID_Wsy) {
                            if ((scoS_Wsy[i].score_Wsy == 0) && (scoS_Wsy[i + 5].score_Wsy== 0) && (scoS_Wsy[i + 10].score_Wsy == 0)) {
                                System.out.println("老师还未给该生录入成绩");
                                break;
                            } else {
                                double sumScore_Wsy = 0;
                                System.out.println("该生的成绩为：");
                                System.out.println("1:计算机网络：" + scoS_Wsy[i].score_Wsy);
                                System.out.println("2:JAVA:" + scoS_Wsy[i + 5].score_Wsy);
                                System.out.println("3:操作系统:" + scoS_Wsy[i + 10].score_Wsy);
                                sumScore_Wsy = scoS_Wsy[i].score_Wsy + scoS_Wsy[i + 5].score_Wsy + scoS_Wsy[i + 10].score_Wsy;
                                System.out.println("该生的总成绩为：" + sumScore_Wsy);
                                double averScore_Wsy = 0;
                                averScore_Wsy = sumScore_Wsy / 3;
                                System.out.println("该生的平均分为：" + averScore_Wsy);
                            }
                        }
                    }
                }
                break;
            }
        }
    }


    static public void luru_Wsy() {
        System.out.println("请选择您教的科目：");
        while (true) {
            System.out.println("0:退出录入");
            System.out.println("1:计算机网络");
            System.out.println("2:Java");
            System.out.println("3:操作系统");
            Scanner kemu_Wsy = new Scanner(System.in);
            int km_Wsy = kemu_Wsy.nextInt();
            switch (km_Wsy) {
                case 0:
                    return;
                case 1:
                    System.out.println("为学生录入《计算机网络》成绩:");
                    for (int i = 0; i < 5; i++) {
                        System.out.println("为学生" + stuS_Wsy[i].studentID_Wsy + stuS_Wsy[i].studentName_Wsy + "录入成绩:");
                        Scanner jiwang_Wsy = new Scanner(System.in);
                        int jw_Wsy = jiwang_Wsy.nextInt();
                        if (jw_Wsy >= 0 && jw_Wsy <= 100) { // 添加成绩合法性检查
                            scoS_Wsy[i].score_Wsy = jw_Wsy;
                        } else {
                            System.out.println("成绩应在0到100之间，请重新录入。");
                        }
                    }
                    break;
                case 2:
                    System.out.println("为学生录入《Java》成绩:");
                    for (int i = 5; i < 10; i++) {
                        System.out.println("为学生" + stuS_Wsy[i - 5].studentID_Wsy + stuS_Wsy[i - 5].studentName_Wsy + "录入成绩:");
                        Scanner jiwang_Wsy = new Scanner(System.in);
                        int jw_Wsy = jiwang_Wsy.nextInt();
                        if (jw_Wsy >= 0 && jw_Wsy <= 100) { // 添加成绩合法性检查
                            scoS_Wsy[i].score_Wsy = jw_Wsy;
                        } else {
                            System.out.println("成绩应在0到100之间，请重新录入。");
                        }
                    }
                    break;
                case 3:
                    System.out.println("为学生录入《操作系统》成绩:");
                    for (int i = 10; i < 15; i++) {
                        System.out.println("为学生" + stuS_Wsy[i - 10].studentID_Wsy + stuS_Wsy[i - 10].studentName_Wsy + "录入成绩:");
                        Scanner jiwang_Wsy = new Scanner(System.in);
                        int jw_Wsy = jiwang_Wsy.nextInt();
                        if (jw_Wsy >= 0 && jw_Wsy <= 100) { // 添加成绩合法性检查
                            scoS_Wsy[i].score_Wsy = jw_Wsy;
                        } else {
                            System.out.println("成绩应在0到100之间，请重新录入。");
                        }
                    }
                    break;

            }
            System.out.println("成绩录入已完成，是否返回到主菜单？");
            System.out.println("0:进行其他操作");
            System.out.println("1:退出");
            Scanner backToMenu_Wsy = new Scanner(System.in);
            int backChoice_Wsy = backToMenu_Wsy.nextInt();

            if (backChoice_Wsy == 1) {
                Exp03ScoreManage_Wsy.scoreManageExec_Wsy(); // 返回到主菜单
            } else if (backChoice_Wsy == 0) {
                return; // 直接退出当前方法
            } else {
                System.out.println("无效的选择，请重新输入。");
            }
        }
    }

    static public void chaxun_Wsy() {
        System.out.println("请学生输入自己编号登录系统 :");
        Scanner SS_Wsy = new Scanner(System.in);
        int S2_Wsy = SS_Wsy.nextInt();
        boolean found = false;
        for (int i = 0; i < 5; i++) {
            if (S2_Wsy == stuS_Wsy[i].studentID_Wsy) {
                found = true;
                double sumScore_Wsy = 0;
                System.out.println("该生的成绩为：");
                System.out.println("1:计算机网络：" + scoS_Wsy[i].score_Wsy);
                System.out.println("2:JAVA:" + scoS_Wsy[i + 5].score_Wsy);
                System.out.println("3:操作系统:" + scoS_Wsy[i + 10].score_Wsy);
                sumScore_Wsy = scoS_Wsy[i].score_Wsy + scoS_Wsy[i + 5].score_Wsy + scoS_Wsy[i + 10].score_Wsy;
                System.out.println("该生的总成绩为：" + sumScore_Wsy);
                double averScore_Wsy = 0;
                averScore_Wsy = sumScore_Wsy / 3;
                System.out.println("该生的平均分为：" + averScore_Wsy);
                break;
            }
        }
        if (!found) {
            System.out.println("未找到该学生的信息。");
        }
    }


    static public void xianshi_Wsy() {
        System.out.println("请选择要显示的内容：");
        System.out.println("1:全体学生成绩");
        System.out.println("2:某个学生所有课程成绩");
        System.out.println("3:某门课程所有学生成绩");
        System.out.println("0:返回上一级菜单");

        Scanner choiceScanner = new Scanner(System.in);
        int choice = choiceScanner.nextInt();

        switch (choice) {
            case 1:
                System.out.println("全体学生成绩:");
                for (int i = 0; i < 15; i++) {
                    System.out.println(
                            "学号：" + stuS_Wsy[i / 3].studentID_Wsy +
                                    ", 姓名：" + stuS_Wsy[i / 3].studentName_Wsy +
                                    ", 课程：" + courS_Wsy[i % 3].courseName_Wsy +
                                    ", 成绩：" + scoS_Wsy[i].score_Wsy
                    );
                }
                break;
            case 2:
                System.out.println("请输入要查询的学生学号:");
                Scanner studentIdScanner = new Scanner(System.in);
                int studentId = studentIdScanner.nextInt();
                int studentIndex = -1;
                for (int i = 0; i < 5; i++) {
                    if (stuS_Wsy[i].studentID_Wsy == studentId) {
                        studentIndex = i;
                        break;
                    }
                }
                if (studentIndex != -1) {
                    System.out.println("该生的成绩为：");
                    System.out.println("1:计算机网络：" + scoS_Wsy[studentIndex].score_Wsy);
                    System.out.println("2:JAVA:" + scoS_Wsy[studentIndex + 5].score_Wsy);
                    System.out.println("3:操作系统:" + scoS_Wsy[studentIndex + 10].score_Wsy);
                } else {
                    System.out.println("未找到该学生的信息。");
                }
                break;
            case 3:
                System.out.println("请输入要查询的课程编号:");
                Scanner courseIdScanner = new Scanner(System.in);
                int courseId = courseIdScanner.nextInt();
                for (int i = 0; i < 3; i++) {
                    if (courS_Wsy[i].courseID_Wsy == courseId) {
                        System.out.println(courS_Wsy[i].courseName_Wsy + "课程所有学生成绩:");
                        for (int j = 0; j < 5; j++) {
                            System.out.println(
                                    "学号：" + stuS_Wsy[j].studentID_Wsy +
                                            ", 姓名：" + stuS_Wsy[j].studentName_Wsy +
                                            ", 成绩：" + scoS_Wsy[i * 5 + j].score_Wsy
                            );
                        }
                        break;
                    }
                }
                break;
            default:
                System.out.println("返回上一级菜单...");
        }
    }


    static public void xiugai_Wsy() {
        System.out.println("请选择要修改的内容：");
        System.out.println("1:修改某个学生某门课程的成绩");
        System.out.println("0:返回上一级菜单");

        Scanner choiceScanner = new Scanner(System.in);
        int choice = choiceScanner.nextInt();

        switch (choice) {
            case 1:
                System.out.println("请输入要修改成绩的学生学号:");
                Scanner studentIdScanner = new Scanner(System.in);
                int studentId = studentIdScanner.nextInt();
                int studentIndex = -1;
                for (int i = 0; i < 5; i++) {
                    if (stuS_Wsy[i].studentID_Wsy == studentId) {
                        studentIndex = i;
                        break;
                    }
                }

                if (studentIndex != -1) {
                    System.out.println("请输入要修改成绩的课程编号:");
                    Scanner courseIdScanner = new Scanner(System.in);
                    int courseId = courseIdScanner.nextInt();
                    for (int i = 0; i < 3; i++) {
                        if (courS_Wsy[i].courseID_Wsy == courseId) {
                            System.out.println("请输入新的成绩:");
                            Scanner newScoreScanner = new Scanner(System.in);
                            int newScore = newScoreScanner.nextInt();
                            if (newScore >= 0 && newScore <= 100) {
                                scoS_Wsy[i * 5 + studentIndex].score_Wsy = newScore;
                                System.out.println("成绩已更新为：" + newScore);
                            } else {
                                System.out.println("成绩应在0到100之间，请重新录入。");
                            }
                            break;
                        }
                    }
                } else {
                    System.out.println("未找到该学生的信息。");
                }
                break;
            default:
                System.out.println("返回上一级菜单...");
        }
    }

    static public void tongji_Wsy() {
        System.out.println("请选择要进行的统计操作：");
        System.out.println("1:计算全体学生的平均成绩");
        System.out.println("2:找出最高分和最低分");
        System.out.println("3:按课程统计各科平均分");
        System.out.println("0:返回上一级菜单");

        Scanner choiceScanner = new Scanner(System.in);
        int choice = choiceScanner.nextInt();

        switch (choice) {
            case 1:
                double totalScore = 0;
                for (int i = 0; i < 15; i++) {
                    totalScore += scoS_Wsy[i].score_Wsy;
                }
                double averageScore = totalScore / 15;
                System.out.printf("全体学生的平均成绩为: %.2f\n", averageScore);
                break;
            case 2:
                int maxScoreIndex = 0;
                int minScoreIndex = 0;
                for (int i = 1; i < 15; i++) {
                    if (scoS_Wsy[i].score_Wsy > scoS_Wsy[maxScoreIndex].score_Wsy) {
                        maxScoreIndex = i;
                    }
                    if (scoS_Wsy[i].score_Wsy < scoS_Wsy[minScoreIndex].score_Wsy) {
                        minScoreIndex = i;
                    }
                }
                System.out.println("最高分学号：" + stuS_Wsy[maxScoreIndex / 3].studentID_Wsy +
                        ", 课程：" + courS_Wsy[maxScoreIndex % 3].courseName_Wsy +
                        ", 分数：" + scoS_Wsy[maxScoreIndex].score_Wsy);
                System.out.println("最低分学号：" + stuS_Wsy[minScoreIndex / 3].studentID_Wsy +
                        ", 课程：" + courS_Wsy[minScoreIndex % 3].courseName_Wsy +
                        ", 分数：" + scoS_Wsy[minScoreIndex].score_Wsy);
                break;
            case 3:
                double[] courseAverages = new double[3];
                for (int i = 0; i < 3; i++) {
                    double courseTotal = 0;
                    for (int j = i * 5; j < (i + 1) * 5; j++) {
                        courseTotal += scoS_Wsy[j].score_Wsy;
                    }
                    courseAverages[i] = courseTotal / 5;
                    System.out.printf("%s课程的平均分为: %.2f\n", courS_Wsy[i].courseName_Wsy, courseAverages[i]);
                }
                break;
            default:
                System.out.println("返回上一级菜单...");
        }
    }
}
