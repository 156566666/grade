package JavaExpAPP_2206006113;

public class Exp03Person_Wsy {
    int Id_Wsy;
    int Name_Wsy;

}
