package JavaExpAPP_2206006113;
import com.sun.rowset.CachedRowSetImpl;
import javax.sql.rowset.CachedRowSet;
import java.sql.*;

public class Exp08Util_Wsy {    //操作数据库的工具类
    String url_Wsy = "jdbc:mysql://localhost:3306/db_JEA_Wsy";
    private Connection con_Wsy;//链接
    private Statement stat_Wsy;//传递sql语句
    private ResultSet rs_Wsy;//接受查询结果

    public boolean IsConn_Wsy() {
        try {
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            con_Wsy = DriverManager.getConnection(url_Wsy, "root", "0000");
            return true;
        } catch (SQLException se) {
            return false;
        } finally {
            try {
                if(con_Wsy != null) con_Wsy.close();
            }catch (SQLException se) {
                return  false;
            }
        }
    }

    public CachedRowSet executeQuery_Wsy(String sql_Wsy) {//数据sql语句结果集
        try {

            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());

            con_Wsy = DriverManager.getConnection(url_Wsy, "root", "0000");

            stat_Wsy = con_Wsy.createStatement();

            rs_Wsy = stat_Wsy.executeQuery(sql_Wsy);

            CachedRowSet crs_Wsy = new CachedRowSetImpl();//变换类型
            crs_Wsy.populate(rs_Wsy);

            return crs_Wsy;//返回sql语句结果
        } catch (SQLException se_Wsy) {
            return null;
        } finally {
            try {
                if(rs_Wsy != null) rs_Wsy.close();
                if(stat_Wsy != null) stat_Wsy.close();
                if(con_Wsy != null) con_Wsy.close();
            }catch (SQLException se_Wsy) {
                return  null;
            }
        }
    }

    public int executeUpdate_Wsy(String sql_Wsy) {//数据定义语言 增 删 改
        try {
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());

            con_Wsy = DriverManager.getConnection(url_Wsy, "root", "0000");

            stat_Wsy = con_Wsy.createStatement();//sql语句

            int count = stat_Wsy.executeUpdate(sql_Wsy);

            return count;

        } catch (SQLException se) {
            return -1;
        } finally {
            try {
                if(rs_Wsy != null) rs_Wsy.close();
                if(stat_Wsy != null) stat_Wsy.close();
                if(con_Wsy != null) con_Wsy.close();
            }catch (SQLException se) {
                return  -1;
            }
        }

    }
}

