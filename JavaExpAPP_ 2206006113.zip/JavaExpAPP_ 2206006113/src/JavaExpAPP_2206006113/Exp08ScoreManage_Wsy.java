package JavaExpAPP_2206006113;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;public class Exp08ScoreManage_Wsy {

    static public void scoreManageExec_Wsy() {
        Exp08Util_Wsy eu_Wsy = new Exp08Util_Wsy();
        if (eu_Wsy.IsConn_Wsy()) {
            System.out.println("数据库连接成功!!!!!!");
            while (true) {
                System.out.println("你是学生还是老师？");
                System.out.println("1:学生");
                System.out.println("2:老师");
                System.out.println("0:退出选择");
                Scanner SX_Wsy=new Scanner(System.in);
                int choice_Wsy=SX_Wsy.nextInt();
                switch (choice_Wsy){
                    case 0:
                        return;
                    case 1:
                        student_Wsy();
                        break;
                    case 2:
                        teacher_Wsy();
                        break;

                }

            }
        } else {
            System.out.println("数据库连接失败");
        }
    }




    static private void teacher_Wsy() {
        Scanner Sc_Wsy=new Scanner(System.in);

        System.out.println("请输入您的TID:(例如:1)");
        String TID_Wsy = Sc_Wsy.next();

        String sql_Wsy = "select * from tb_Teacher_Wsy where TID_Wsy=' " + TID_Wsy + " ' ";

        ResultSet rs_Wsy = new Exp08Util_Wsy().executeQuery_Wsy(sql_Wsy);//接收查询结果


            try {
                if (rs_Wsy.next()){
                    System.out.println("登录成功");
                    while (true){
                        System.out.println("请输入你想完成的操作：");
                        System.out.println("0:退出系统");
                        System.out.println("1:录入");
                        System.out.println("2:显示");
                        System.out.println("3:查询");
                        System.out.println("4:修改");
                        System.out.println("5:统计");
                        Scanner c_Wsy = new Scanner(System.in);
                        int Choice_Wsy = c_Wsy.nextInt();
                        switch (Choice_Wsy) {
                            case 0:
                                return;
                            case 1://录入成绩


                                //System.out.println("例如:UPDATE `tb_score_Wsy` set `S_jiwang_Wsy` = 3 WHERE `SID_Wsy` = 1");
/*
                                String number_Wsy=Sc_Wsy.nextLine();//吃掉换行符
                                String sql1_Wsy=Sc_Wsy.nextLine();
*/
                                int tid_Wsy;
                                tid_Wsy=Integer.parseInt(TID_Wsy);
                                System.out.println("您的TID为:"+TID_Wsy);
                                if (tid_Wsy==1){
                                    System.out.println("您是计算机网络科目的老师，为学生们录入计网科目的成绩: ");
                                    for (int i_Wsy = 1; i_Wsy < 6; i_Wsy++) {
                                        String SID_Wsy=Integer.toString(i_Wsy);
                                        System.out.println("请输入第"+(i_Wsy)+"个学生的成绩:");
                                        int score_jiwang =c_Wsy.nextInt();
                                        String sql1_Wsy="UPDATE tb_score_Wsy set S_jiwang_Wsy= "+score_jiwang+" where SID_Wsy='" + SID_Wsy + "'";

                                        int count =new Exp08Util_Wsy().executeUpdate_Wsy(sql1_Wsy);

                                        if (count==1){
                                            System.out.println("该同学成绩录入成功");
                                        }else {
                                            System.out.println("该同学成绩录入失败");
                                        }
                                    }
                                } else if (tid_Wsy ==2) {
                                    System.out.println("您是Java科目的老师，为学生们录入Java科目的成绩: ");//问题：i为0 但是sql里面默认1开始
                                    for (int i_Wsy = 1; i_Wsy < 6; i_Wsy++) {
                                        String SID_Wsy=Integer.toString(i_Wsy);
                                        System.out.println("请输入第"+(i_Wsy)+"个学生的成绩:");
                                        int score_java =c_Wsy.nextInt();
                                        String sql1_Wsy="UPDATE tb_score_Wsy set S_Java_Wsy= "+score_java+" where SID_Wsy='" + SID_Wsy + "'";
                                        int count =new Exp08Util_Wsy().executeUpdate_Wsy(sql1_Wsy);

                                        if (count==1){
                                            System.out.println("该同学成绩录入成功");
                                        }else {
                                            System.out.println("该同学成绩录入失败");
                                        }
                                    }
                                } else if (tid_Wsy==3) {
                                    System.out.println("您是操作系统科目的老师，为学生们录入操作系统科目的成绩: ");
                                    for (int i_Wsy = 1; i_Wsy < 6; i_Wsy++) {
                                        String SID_Wsy=Integer.toString(i_Wsy);
                                        System.out.println("请输入第"+(i_Wsy)+"个学生的成绩:");
                                        int score_caozuo =c_Wsy.nextInt();
                                        String sql1_Wsy="UPDATE tb_score_Wsy set S_caozuo_Wsy= "+score_caozuo+" where SID_Wsy='" + SID_Wsy + "'";
                                        int count =new Exp08Util_Wsy().executeUpdate_Wsy(sql1_Wsy);

                                        if (count==1){
                                            System.out.println("该同学成绩录入成功");
                                        }else {
                                            System.out.println("该同学成绩录入失败");
                                        }
                                    }
                                }
                                break;
                            case 2://显示
                                System.out.println("显示学生成绩:");
                                String sql2_Wsy=" select * from tb_score_Wsy";

                                ResultSet rs1_Wsy =new Exp08Util_Wsy().executeQuery_Wsy(sql2_Wsy);

                                if (rs1_Wsy==null){
                                    System.out.println("结果集对象为空,没有成功接收结果!!!!");
                                }else {
                                    System.out.println("结果集不为空，成功接收结果!!!!!!");
                                }

                                while (rs1_Wsy.next()) {
                                    int id_Wsy = rs1_Wsy.getInt("SID_Wsy");
                                    String name_Wsy = rs1_Wsy.getString("S_Name_Wsy"); // 使用getString()方法获取字符串字段
                                    int jiwang_Wsy=rs1_Wsy.getInt("S_jiwang_Wsy");
                                    int Java_Wsy=rs1_Wsy.getInt("S_Java_Wsy");
                                    int caozuo_Wsy=rs1_Wsy.getInt("S_caozuo_Wsy");
                                    System.out.println("SID =" + id_Wsy + ", Name =" + name_Wsy+", 计网: "+jiwang_Wsy+", Java:"+Java_Wsy+", 操作系统:"+caozuo_Wsy);
                                }


                                break;
                            case 3://查询
                                System.out.println("请使用sql语句为学生们查询成绩:");
                                System.out.println("例如:SELECT * FROM tb_score_Wsy ");
                                //String sql3_Wsy=Sc_Wsy.next();
                                //int SID_Wsy=1;
                                String number1_Wsy=Sc_Wsy.nextLine();//吃掉换行符
                                while (true) {
                                    System.out.println("你想要进行的操作:");
                                    System.out.println("1:查询一个人的成绩");
                                    System.out.println("2:查询所有人的成绩");
                                    System.out.println("0:推出查询");
                                    Scanner sc_Wsy=new Scanner(System.in);
                                    int ch_Wsy=sc_Wsy.nextInt();
                                    switch (ch_Wsy){
                                        case 0:
                                            return;
                                        case 1:
                                            System.out.println("请输入您想要查询的学生的SID_Wsy:");
                                            int SID_Wsy=sc_Wsy.nextInt();

                                            String sql5_Wsy="select * from tb_score_Wsy where SID_Wsy='" + SID_Wsy + "'";
                                            ResultSet rs2_Wsy=new Exp08Util_Wsy().executeQuery_Wsy(sql5_Wsy);
                                            if (rs2_Wsy==null){
                                                System.out.println("结果集对象为空,没有成功接收结果!!!!");
                                            }else {
                                                System.out.println("结果集不为空，成功接收结果!!!!!!");
                                            }
                                            while (rs2_Wsy.next()) {
                                                int id_Wsy = rs2_Wsy.getInt("SID_Wsy");
                                                String name_Wsy = rs2_Wsy.getString("S_Name_Wsy"); // 使用getString()方法获取字符串字段
                                                int jiwang_Wsy=rs2_Wsy.getInt("S_jiwang_Wsy");
                                                int Java_Wsy=rs2_Wsy.getInt("S_Java_Wsy");
                                                int caozuo_Wsy=rs2_Wsy.getInt("S_caozuo_Wsy");
                                                System.out.println("SID =" + id_Wsy + ", Name =" + name_Wsy+", 计网="+jiwang_Wsy+", Java="+Java_Wsy+", 操作系统="+caozuo_Wsy);
                                            }
                                            break;
                                        case 2:
                                            String sql6_Wsy="select * from tb_score_Wsy";
                                            ResultSet rs3_Wsy=new Exp08Util_Wsy().executeQuery_Wsy(sql6_Wsy);
                                            if (rs3_Wsy==null){
                                                System.out.println("结果集对象为空,没有成功接收结果!!!!");
                                            }else {
                                                System.out.println("结果集不为空，成功接收结果!!!!!!");
                                            }
                                            while (rs3_Wsy.next()) {
                                                int id_Wsy = rs3_Wsy.getInt("SID_Wsy");
                                                String name_Wsy = rs3_Wsy.getString("S_Name_Wsy"); // 使用getString()方法获取字符串字段
                                                int jiwang_Wsy=rs3_Wsy.getInt("S_jiwang_Wsy");
                                                int Java_Wsy=rs3_Wsy.getInt("S_Java_Wsy");
                                                int caozuo_Wsy=rs3_Wsy.getInt("S_caozuo_Wsy");
                                                System.out.println("SID =" + id_Wsy + ", Name =" + name_Wsy+", 计网="+jiwang_Wsy+", Java="+Java_Wsy+", 操作系统="+caozuo_Wsy);
                                            }
                                            break;
                                    }
                                }
                                /*
                                //ResultSet rs2_Wsy=new Exp08Util_Wsy().executeQuery_Wsy(sql3_Wsy);
                                if (rs2_Wsy==null){
                                    System.out.println("结果集对象为空,没有成功接收结果!!!!");
                                }else {
                                    System.out.println("结果集不为空，成功接收结果!!!!!!");
                                }
                                while (rs2_Wsy.next()) {
                                    int id_Wsy = rs2_Wsy.getInt("SID_Wsy");
                                    String name_Wsy = rs2_Wsy.getString("S_Name_Wsy"); // 使用getString()方法获取字符串字段
                                    int jiwang_Wsy=rs2_Wsy.getInt("S_jiwang_Wsy");
                                    int Java_Wsy=rs2_Wsy.getInt("S_Java_Wsy");
                                    int caozuo_Wsy=rs2_Wsy.getInt("S_caozuo_Wsy");
                                    System.out.println("SID =" + id_Wsy + ", Name =" + name_Wsy+"计网"+jiwang_Wsy+"Java"+Java_Wsy+"操作系统"+caozuo_Wsy);
                                }
*/
                            case 4://修改
                                Scanner QQ_Wsy=new Scanner(System.in);
                                boolean continueModifying_Wsy = true;//控制循环
                                //System.out.println("例如:UPDATE `tb_score_Wsy` set `S_jiwang_Wsy` = 3 WHERE `SID_Wsy` = 1");
                                do {
                                    int ttid_Wsy;
                                    ttid_Wsy = Integer.parseInt(TID_Wsy);
                                    if (ttid_Wsy == 1) {
                                        System.out.println("您是计算机网络科目的老师，为学生修改计网科目的成绩: ");
                                        System.out.println("请输入你想修改学生成绩的SID_Wsy");
                                        int i_Wsy = QQ_Wsy.nextInt();
                                        String SID_Wsy = Integer.toString(i_Wsy);
                                        System.out.println("___________________________________");
                                        System.out.println("请输入修改的成绩:");

                                        int score_jiwang = c_Wsy.nextInt();
                                        String sql1_Wsy = "UPDATE tb_score_Wsy set S_jiwang_Wsy= " + score_jiwang + " where SID_Wsy='" + SID_Wsy + "'";
                                        int count = new Exp08Util_Wsy().executeUpdate_Wsy(sql1_Wsy);
                                        if (count == 1) {
                                            System.out.println("该同学成绩修改成功");
                                        } else {
                                            System.out.println("该同学成绩修改失败");
                                        }
                                        System.out.println("成绩修改完成。");
                                        System.out.println("是否继续修改其他成绩？(yes/no)");
                                        String choice = QQ_Wsy.next().toLowerCase(); // 转换为小写，方便比较

                                        if ("no".equals(choice)) {
                                            continueModifying_Wsy = false; // 用户选择退出，设置标志为false
                                        } else if (!"yes".equals(choice)) {
                                            System.out.println("输入无效，请输入 'yes' 继续修改或 'no' 退出。");
                                        }
                                    } else if (ttid_Wsy == 2) {
                                        System.out.println("您是Java科目的老师，为学生修改java科目的成绩: ");
                                        System.out.println("请输入你想修改学生成绩的SID_Wsy");
                                        int i_Wsy = QQ_Wsy.nextInt();
                                        String SID_Wsy = Integer.toString(i_Wsy);
                                        System.out.println("___________________________________");
                                        System.out.println("请输入修改的成绩:");
                                        int score_java = c_Wsy.nextInt();
                                        String sql1_Wsy = "UPDATE tb_score_Wsy set S_Java_Wsy= " + score_java + " where SID_Wsy='" + SID_Wsy + "'";
                                        int count = new Exp08Util_Wsy().executeUpdate_Wsy(sql1_Wsy);

                                        if (count == 1) {
                                            System.out.println("该同学成绩修改成功");
                                        } else {
                                            System.out.println("该同学成绩修改失败");
                                        }


                                        System.out.println("成绩修改完成。");
                                        System.out.println("是否继续修改其他成绩？(yes/no)");
                                        String choice = QQ_Wsy.next().toLowerCase(); // 转换为小写，方便比较

                                        if ("no".equals(choice)) {
                                            continueModifying_Wsy = false; // 用户选择退出，设置标志为false
                                        } else if (!"yes".equals(choice)) {
                                            System.out.println("输入无效，请输入 'yes' 继续修改或 'no' 退出。");
                                        }


                                    } else if (ttid_Wsy == 3) {
                                        System.out.println("您是操作系统科目的老师，为学生修改操作系统科目的成绩: ");
                                        System.out.println("请输入你想修改学生成绩的SID_Wsy");
                                        int i_Wsy = QQ_Wsy.nextInt();
                                        String SID_Wsy = Integer.toString(i_Wsy);
                                        System.out.println("___________________________________");
                                        System.out.println("请输入修改的成绩:");
                                        int score_caozuo = c_Wsy.nextInt();

                                        String sql1_Wsy = "UPDATE tb_score_Wsy set S_caozuo_Wsy= " + score_caozuo + " where SID_Wsy='" + SID_Wsy + "'";
                                        int count = new Exp08Util_Wsy().executeUpdate_Wsy(sql1_Wsy);

                                        if (count == 1) {
                                            System.out.println("该同学成绩修改成功");
                                        } else {
                                            System.out.println("该同学成绩修改失败");
                                        }
                                        System.out.println("成绩修改完成。");
                                        System.out.println("是否继续修改其他成绩？(yes/no)");
                                        String choice = QQ_Wsy.next().toLowerCase(); // 转换为小写，方便比较

                                        if ("no".equals(choice)) {
                                            continueModifying_Wsy = false; // 用户选择退出，设置标志为false
                                        } else if (!"yes".equals(choice)) {
                                            System.out.println("输入无效，请输入 'yes' 继续修改或 'no' 退出。");
                                        }
                                    }
                                }while (continueModifying_Wsy);
                                System.out.println("已退出成绩修改，返回主菜单...");

                                break;
                            case 5://统计
                                //问题:
                                String sql4_Wsy="SELECT *,SUM( S_jiwang_Wsy + S_Java_Wsy + S_caozuo_Wsy ) AS sumscore FROM tb_score_Wsy GROUP BY SID_Wsy;";
                                ResultSet rs3_Wsy =new Exp08Util_Wsy().executeQuery_Wsy(sql4_Wsy);
                                ResultSet r1_Wsy=new Exp08Util_Wsy().executeQuery_Wsy(sql4_Wsy);
                                if (r1_Wsy==null){
                                    System.out.println("求和失败");
                                }else {
                                    System.out.println("求和成功");
                                }

                                while (rs3_Wsy.next()) {
                                    int id_Wsy = rs3_Wsy.getInt("SID_Wsy");
                                    String name_Wsy = rs3_Wsy.getString("S_Name_Wsy");
                                    int jiwang_Wsy = rs3_Wsy.getInt("S_jiwang_Wsy");
                                    int Java_Wsy = rs3_Wsy.getInt("S_Java_Wsy");
                                    int caozuo_Wsy = rs3_Wsy.getInt("S_caozuo_Wsy");

                                    // 使用"sumscore"获取计算后的总分
                                    int sumscore_Wsy = rs3_Wsy.getInt("sumscore");

                                    System.out.println("SID =" + id_Wsy + ", Name =" + name_Wsy + ", 计网: " + jiwang_Wsy + ", Java: " + Java_Wsy + ", 操作系统: " + caozuo_Wsy + ", 总成绩: " + sumscore_Wsy);
                                }
                                break;
                        }
                    }
                }
                else {
                    System.out.printf("用户不存在");
                }
            } catch (SQLException se_Wsy) {
                System.out.println(se_Wsy.getMessage());
            } catch (NullPointerException SE_Wsy) {
                SE_Wsy.getMessage();
                System.out.println("程序出错！！！！");
            }



    }

    static private void student_Wsy() {
        Scanner Sc_Wsy=new Scanner(System.in);

        System.out.println("请输入您的SID:(例如：1)");
        String SID_Wsy = Sc_Wsy.next();

        String sql_Wsy = "select * from tb_student_Wsy where SID_Wsy='" + SID_Wsy + "'";

        ResultSet rs_Wsy = new Exp08Util_Wsy().executeQuery_Wsy(sql_Wsy);//接收查询结果

        try {
            if (rs_Wsy.next()) {
                System.out.println("学生登录成功");

                String sql1_Wsy="select * from tb_score_Wsy where SID_Wsy='" + SID_Wsy + "'";

                ResultSet rs1_Wsy =new Exp08Util_Wsy().executeQuery_Wsy(sql1_Wsy);


                if (rs1_Wsy==null){
                    System.out.println("结果集对象为空,没有成功接收结果!!!!");
                }else {
                    System.out.println("结果集不为空，成功接收结果!!!!!!");
                }

                while (rs1_Wsy.next()) {
                    int id_Wsy = rs1_Wsy.getInt("SID_Wsy");
                    String name_Wsy = rs1_Wsy.getString("S_Name_Wsy"); // 使用getString()方法获取字符串字段
                    int jiwang_Wsy=rs1_Wsy.getInt("S_jiwang_Wsy");
                    int Java_Wsy=rs1_Wsy.getInt("S_Java_Wsy");
                    int caozuo_Wsy=rs1_Wsy.getInt("S_caozuo_Wsy");
                     //int sumscore_Wsy=rs1_Wsy.getInt("sumscore");
                    if(jiwang_Wsy==0){
                        System.out.println("该学生计网科目成绩没有录入");
                    } else if (Java_Wsy==0) {
                        System.out.println("该学生Java科目成绩没有录入");
                    } else if (caozuo_Wsy==0) {
                        System.out.println("该学生操作系统科目成绩没有录入");
                    } else {
                        System.out.println("SID :" + id_Wsy + ", Name:" + name_Wsy + ", 计网: " + jiwang_Wsy + ", Java:" + Java_Wsy + ", 操作系统:" + caozuo_Wsy);
                    }
                }





            }

        } catch (SQLException se_Wsy) {
            System.out.println(se_Wsy.getMessage());

        } catch (NullPointerException SE_Wsy) {

            SE_Wsy.getMessage();
            System.out.println("程序出错了!!");
        }
    }
}
