package JavaExpAPP_2206006113;

import java.io.File;
import java.io.*;
import java.io.FileInputStream;
import java.util.Date;
import java.util.Scanner;

import java.util.Date;
import java.text.SimpleDateFormat;

public class Exp07_Wsy {


    void menu_Wsy(){

        while (true){

            System.out.println("请选择:");
            System.out.println("0:退出");
            System.out.println("1:成绩管理系统（文件版）");
            System.out.println("2:显示文件夹和文件");
            Scanner SS_Wsy=new Scanner(System.in);
            int choice_Wsy=SS_Wsy.nextInt();
            switch (choice_Wsy){
                case 0:
                    return;
                case 1:
                    grademanageFile_Wsy();
                    break;
                case 2:
                    displayDF_Wsy();
                    break;
            }
        }
    }

    void grademanageFile_Wsy(){
        Exp07ScoreManage_Wsy ScoreManage_Wsy = new Exp07ScoreManage_Wsy();//成绩录入类

        System.out.println("请录入成绩!!");
        ScoreManage_Wsy.scoreManageExec_Wsy();//录入成绩

        //创建文件
        File file1_Wsy = new File("src\\Exp07Teacher_Wsy.txt");
        File file2_Wsy = new File("src\\Exp07Student_Wsy.txt");
        File file3_Wsy = new File("src\\Exp07Course_Wsy.txt");
        File file4_Wsy = new File("src\\Exp07Score_Wsy.txt");

        //字符流输入进文件
        FileWriter ff1_Wsy=null;//创建文件写入对象
        FileWriter ff2_Wsy=null;
        FileWriter ff3_Wsy=null;
        FileWriter ff4_Wsy=null;

        BufferedWriter f1_Wsy=null;//创建字符流写入对象
        BufferedWriter f2_Wsy=null;
        BufferedWriter f3_Wsy=null;
        BufferedWriter f4_Wsy=null;


        if(file1_Wsy.exists()) {//判断是否创建文件
            System.out.println("文件已经存在");
        }else {
            try {
                file1_Wsy.createNewFile();
                System.out.println("文件创建成功");
            } catch (Exception e) {
                // TODO: handle exception
            }
        }

        System.out.println("文件已经存在:"+file1_Wsy.exists());
        System.out.println("文件的名字:"+file1_Wsy.getName());
        System.out.println("文件的路径:"+file1_Wsy.getPath());
        System.out.println("文件的绝对路径:"+file1_Wsy.getAbsolutePath());
        //System.out.println("是目录吗:"+file1_Wsy.isDirectory());
        System.out.println("文件大小:"+file1_Wsy.length());




      try {
          System.out.println("文件打开成功!!!!!");
          System.out.println("输入的信息已经成功保存在txt文件中！！！");

          ff1_Wsy=new FileWriter(file1_Wsy);//创建file1文件
          ff2_Wsy=new FileWriter(file2_Wsy);
          ff3_Wsy=new FileWriter(file3_Wsy);
          ff4_Wsy=new FileWriter(file4_Wsy);


           f1_Wsy=new BufferedWriter(ff1_Wsy);
           f2_Wsy=new BufferedWriter(ff2_Wsy);
           f3_Wsy=new BufferedWriter(ff3_Wsy);
           f4_Wsy=new BufferedWriter(ff4_Wsy);


            String t_Wsy=Exp07ScoreManage_Wsy.scoS_Wsy[0].teaName_Wsy;
            String Stu_Wsy=Exp07ScoreManage_Wsy.scoS_Wsy[0].stuName_Wsy;
            String c_Wsy=Exp07ScoreManage_Wsy.scoS_Wsy[0].courName_Wsy;


            int Sco_Wsy=Exp07ScoreManage_Wsy.scoS_Wsy[0].score_Wsy;
            String SS_Wsy=Integer.toString(Sco_Wsy);


            /*if ( Sco_Wsy!=0 ){
                while (true) {

                    System.out.println("此科已经录入完毕成绩，请你选择将进行操作");

                    System.out.println("0:退出选择");
                    System.out.println("1:重新录入");


                    Scanner CC_Wsy=new Scanner(System.in);
                    int cc_Wsy=CC_Wsy.nextInt();

                    switch (cc_Wsy) {
                        case 0:

                            return;

                        case 1:

                          Exp07ScoreManage_Wsy.luru_Wsy();

                        break;

                    }
                }
            }*/


            //写入文件
              f1_Wsy.write(t_Wsy);

              f2_Wsy.write(Stu_Wsy);

              f3_Wsy.write(c_Wsy);

              f4_Wsy.write(SS_Wsy);



        }catch (Exception e1_Wsy){

            System.out.println("文件打开失败!!!!");

        }finally {
            try {
                //关闭保存文件
                f1_Wsy.close();
                f2_Wsy.close();
                f3_Wsy.close();
                f4_Wsy.close();

                ff1_Wsy.close();
                ff2_Wsy.close();
                ff3_Wsy.close();
                ff4_Wsy.close();

            }catch (Exception e2_Wsy){
                System.out.println("关闭文件失败!!!!");
            }
      }


    }

    void  fileTest_Wsy(){//递归函数
        System.out.println("____________________");
        System.out.println("请输入一个路径");
        Scanner SQ_Wsy=new Scanner(System.in);

        //路径   这里写一个路径进去
        String path_Wsy=SQ_Wsy.nextLine();

        //调用方法
        getFiles_ALL_Wsy(path_Wsy);//开始输出

        //long now_Wsy = System.currentTimeMillis();//获取时间
        //long time_Wsy=now_Wsy;//记录下操作的时间
        //System.out.println("最后修改时间为:"+time_Wsy);

        System.out.println("——————————————————————————");

    }


    static void getFiles_ALL_Wsy(String path_Wsy) {
        File file_Wsy = new File(path_Wsy);


        // 如果这个路径是文件夹
        if (file_Wsy.isDirectory()) {

            File[] files_Wsy = file_Wsy.listFiles();//将该文件夹所有子文件存入文件的对象数组
            for (int i_Wsy = 0; i_Wsy < files_Wsy.length; i_Wsy++) {
                // 如果还是文件夹 递归获取里面的文件 文件夹
                if (files_Wsy[i_Wsy].isDirectory()) {
                    //long time_Wsy=files_Wsy[i].lastModified();
                    // Date date_Wsy=new Date(time_Wsy);
                    String lastModifiedTime_Wsy = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss").format(new Date(files_Wsy[i_Wsy].lastModified()));
                    System.out.println("文件夹:盘符:" + files_Wsy[i_Wsy].getPath());
                    System.out.println("最后修改时间:"+lastModifiedTime_Wsy);
                    getFiles_ALL_Wsy(files_Wsy[i_Wsy].getPath());//递归
                } else {
                    String lastModifiedTime_Wsy = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss").format(new Date(files_Wsy[i_Wsy].lastModified()));
                    System.out.println("文件:盘符:" + files_Wsy[i_Wsy].getPath());
                    System.out.println("大小:"+files_Wsy[i_Wsy].length()+" M");
                    System.out.println("最后修改时间:"+lastModifiedTime_Wsy);
                }
            }
        } else {
            System.out.println("文件:盘符：" + file_Wsy.getPath());
        }

    }

    /*
    void getfile_file_Wsy(String path_Wsy){//只输出文件
        File file_Wsy = new File(path_Wsy);
        // 如果这个路径是文件夹
        if (file_Wsy.isDirectory()) {
            File[] files_Wsy = file_Wsy.listFiles();//将该文件夹所有子文件存入文件的对象数组
            for (int i_Wsy = 0; i_Wsy < files_Wsy.length; i_Wsy++) {
                // 如果还是文件夹 递归获取里面的文件 文件夹
                if (files_Wsy[i_Wsy].isDirectory()) {
                    //long time_Wsy=files_Wsy[i].lastModified();
                    // Date date_Wsy=new Date(time_Wsy);
                    String lastModifiedTime_Wsy = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss").format(new Date(files_Wsy[i_Wsy].lastModified()));
                    System.out.println("文件夹:盘符:" + files_Wsy[i_Wsy].getPath());
                    System.out.println("最后修改时间:"+lastModifiedTime_Wsy);
                    getFiles_ALL_Wsy(files_Wsy[i_Wsy].getPath());//递归
                } else {
                    String lastModifiedTime_Wsy = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss").format(new Date(files_Wsy[i_Wsy].lastModified()));
                    System.out.println("文件:盘符:" + files_Wsy[i_Wsy].getPath());
                    System.out.println("大小:"+files_Wsy[i_Wsy].length()+" M");
                    System.out.println("最后修改时间:"+lastModifiedTime_Wsy);
                }
            }
        } else {
            System.out.println("文件:盘符：" + file_Wsy.getPath());
        }
    }
*/
    /*
    void getfile_dir_Wsy(String path_Wsy){//只显示文件夹
            File file_Wsy=new File(path_Wsy);

            if (file_Wsy.isDirectory()){
                File[]  files_Wsy=file_Wsy.listFiles();//将


            }
    }

*/

    void displayDF_Wsy(){//显示文件夹和文件

        while (true){
            System.out.println("请选择你想进行的操作:");
            System.out.println("________________________");
            System.out.println("0:退出选择");
            System.out.println("1:显示文件夹");
            System.out.println("2:显示文件");
            System.out.println("3:显示文件夹和文件");
            System.out.println("________________________");

            Scanner SA_Wsy=new Scanner(System.in);
            int choice_Wsy=SA_Wsy.nextInt();
            switch (choice_Wsy){
                case 0:
                    return;
                case 1:




                    break;
                case 2:



                    break;

                case 3:
                    fileTest_Wsy();
                    break;
            }




        }

    }


}


