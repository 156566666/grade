package JavaExpAPP_2206006113;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        while (true) {
            System.out.println("选择:");
            System.out.println("0:退出选择");
            System.out.println("1:实验一");
            System.out.println("2:实验二");
            System.out.println("3:实验三");
            System.out.println("4:实验四");
            System.out.println("5:实验五");
            System.out.println("6:实验六");
            System.out.println("7:实验七");
            System.out.println("8:实验八");
            Scanner SD_Wsy = new Scanner(System.in);
            int choice_Wsy = SD_Wsy.nextInt();
            switch (choice_Wsy) {
                case 0:
                    return;
                case 1:
                    Exp01_Wsy exp001_Wsy = new Exp01_Wsy();
                    exp001_Wsy.menu_Wsy();
                    break;
                case 2:
                    Exp02_Wsy exp002_Wsy = new Exp02_Wsy();
                    exp002_Wsy.menu_Wsy();
                    break;
                case 3:
                    Exp03_Wsy exp003_Wsy = new Exp03_Wsy();
                    exp003_Wsy.menu_Wsy();
                    break;
                case 4:
                    Exp04_Wsy exp004_Wsy=new Exp04_Wsy();
                    exp004_Wsy.menu_Wsy();
                    break;

                case 5:
                    Exp05_Wsy exp005_Wsy=new Exp05_Wsy();
                    exp005_Wsy.menu_Wsy();
                    break;
                case 6:
                    Exp06_Wsy exp006_Wsy=new Exp06_Wsy();
                    exp006_Wsy.menu_Wsy();
                    break;
                case 7:
                    Exp07_Wsy exp007_Wsy=new Exp07_Wsy();
                    exp007_Wsy.menu_Wsy();
                    break;
                case 8:
                    Exp08ScoreManage_Wsy exp008_Wsy=new Exp08ScoreManage_Wsy();
                    exp008_Wsy.scoreManageExec_Wsy();
                    break;
            }
        }
    }
}