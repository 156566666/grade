package JavaExpAPP_2206006113;

import java.util.Scanner;

public class Exp03_Wsy {
    public static Exp03Goods_Wsy[] Goods_Wsy;

    public static void main(String[] args) {

    }

    void menu_Wsy(){
        while (true) {
            System.out.println("请选择你想进行的选项");
            System.out.println("0:退出选择");
            System.out.println("1:成绩管理系统");
            System.out.println("2:进货和售货");
            System.out.println("3:园和圆柱体");
            Scanner SC_Wsy=new Scanner(System.in);
            int choice_Wsy=SC_Wsy.nextInt();
            switch (choice_Wsy){
                case 0:
                    return;
                case 1:
                    Exp03ScoreManage_Wsy  ScoreManage_Wsy =new Exp03ScoreManage_Wsy();
                    ScoreManage_Wsy.scoreManageExec_Wsy();
                    break;
                case 2:
                    goodsExec_Wsy();
                    break;
                case 3:
                    circleExec_Wsy();
                    break;

            }
        }
    }
    public void goodsExec_Wsy(){
        System.out.println("进货");
       Exp03BuyGoods_Wsy exp31_Wsy=new Exp03BuyGoods_Wsy();
       exp31_Wsy.getGoods_Wsy();
       exp31_Wsy.showGoods_Wsy();
        System.out.println("售货");
        Exp03SaleGoods_Wsy exp32_Wsy=new Exp03SaleGoods_Wsy();
        exp32_Wsy.InitSaleCount_Wsy();
        exp32_Wsy.ShowSaleNum();
    }

    public void circleExec_Wsy(){
        Exp03Circle_Wsy exp3_Wsy=new Exp03Circle_Wsy();
        exp3_Wsy.circleExec_Wsy();
    }
}
