package JavaExpAPP_2206006113;

 public class Exp02Score_Wsy {
        int score_Wsy;
        String teaName_Wsy;
        String stuName_Wsy;
        String courName_Wsy;

        public Exp02Score_Wsy(String teaName_Wsy,String stuName_Wsy,String courName_Wsy,int score_Wsy){
            this.teaName_Wsy=teaName_Wsy;
            this.stuName_Wsy=stuName_Wsy;
            this.courName_Wsy=courName_Wsy;
            this.score_Wsy=score_Wsy;
        }
    static public class Exp02Student_Wsy {
        int studentID_Wsy;
        String studentName_Wsy;
        public Exp02Student_Wsy(int ID_Wsy,String name_Wsy){
            studentID_Wsy=ID_Wsy;
            studentName_Wsy=name_Wsy;
        }

    }

    static public class Exp02Teacher_Wsy {
        int teacherId_Wsy;
        String teacherName_Wsy;
        public Exp02Teacher_Wsy(int Id_Wsy,String name_Wsy){
            teacherId_Wsy=Id_Wsy;
            teacherName_Wsy=name_Wsy;
        }
    }

   static public class Exp02Course_Wsy{
        int courseID_Wsy;
        String courseName_Wsy;
        public Exp02Course_Wsy (int id_Wsy,String name_Wsy){
            courseID_Wsy=id_Wsy;
            courseName_Wsy=name_Wsy;
        }
    }

    public static void main(String[] args) {

    }


}
