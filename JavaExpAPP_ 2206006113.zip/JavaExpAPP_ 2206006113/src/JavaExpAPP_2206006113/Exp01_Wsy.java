package JavaExpAPP_2206006113;
import java.util.Scanner;

public class Exp01_Wsy {
    public void menu_Wsy() {
        while (true) {
            System.out.println("请选择：");
            System.out.println("0:结束");
            System.out.println("1:面积和周长");
            System.out.println("2:成绩和等级");
            System.out.println("3:求近似值");
            System.out.println("4:if公式计算");
            System.out.println("5:switch公式计算");
            Scanner sc_Wsy = new Scanner(System.in);
            int choice_Wsy = sc_Wsy.nextInt();
            if (choice_Wsy < 0) {
                System.out.println("不能选择负数");
                continue;
            }
            switch (choice_Wsy) {
                case 0:
                    System.out.println("结束菜单");
                    return;
                case 1:
                    area_Perimeter_Wsy();
                    break;
                case 2:
                    greadegree_Wsy_Wsy();
                    break;
                case 3:
                    approximate_Wsy();
                    break;
                case 4:
                    
                    double y_WuSiYuan=0;
                    System.out.println("输入t值：");
                    Scanner S_WuSiYuan=new Scanner(System.in);
                    double t_WuSiYuan= S_WuSiYuan.nextDouble();
                    formulaIf_WuSiYuan(t_WuSiYuan,y_WuSiYuan);
                    break;
                case  5:
                    double j_WuSiYuan=0;
                    System.out.println("输入t值：");
                    Scanner sx_Wsy=new Scanner(System.in);
                    int h_WuSiYuan= sx_Wsy.nextInt();
                    formulaSwitch_WuSiYuan(h_WuSiYuan,j_WuSiYuan);
                    break;
            }
        }

    }
    void area_Perimeter_Wsy () {
        System.out.println("输入矩形的长和宽");
        Scanner sc_Wsy=new Scanner(System.in);
        Scanner sx_Wsy=new Scanner(System.in);
        double chang_Wsy=sc_Wsy.nextDouble();
        double width_Wsy=sx_Wsy.nextDouble();
        double area_Wsy;
        double perimeter_WuSiYuan;
        if((chang_Wsy>0&&chang_Wsy<=30)&&(width_Wsy>0&&width_Wsy<=30)) {
            area_Wsy = chang_Wsy * width_Wsy;
            perimeter_WuSiYuan = 2 * (chang_Wsy + width_Wsy);
            System.out.println("矩形面积是："+area_Wsy);
            System.out.println("矩形周长是: "+perimeter_WuSiYuan);
        }
        else if(chang_Wsy>0&&chang_Wsy<=30) {
            area_Wsy =3.14*chang_Wsy*chang_Wsy;
            perimeter_WuSiYuan=2*3.14*chang_Wsy;
            System.out.println("圆的面积是:"+area_Wsy);
            System.out.println("圆的周长是:"+perimeter_WuSiYuan);
        }
        else if(width_Wsy>0&&width_Wsy<=30){
            area_Wsy =3.14*width_Wsy*width_Wsy;
            perimeter_WuSiYuan=2*3.14*width_Wsy;
            System.out.println("圆的面积是:"+area_Wsy);
            System.out.println("圆的周长是:"+perimeter_WuSiYuan);
        }
        else if((chang_Wsy<=0||chang_Wsy>30)&&(width_Wsy<=0||width_Wsy>30)){
            System.out.println("输入数据无效");
        }

    }
    void greadegree_Wsy_Wsy() {
        System.out.println("请输入学生的成绩：");
        Scanner sb_Wsy=new Scanner(System.in);
        System.out.println("数据库:");
        int shujuku_Wsy=sb_Wsy.nextInt();
        System.out.println("Java:");
        int javal_Wsy=sb_Wsy.nextInt();
        System.out.println("英语：");
        int English_Wsy=sb_Wsy.nextInt();
        if (shujuku_Wsy>90){
            System.out.println("数据库等级: 优，成绩："+shujuku_Wsy);
        } else if(shujuku_Wsy>80&&shujuku_Wsy<90) {
            System.out.println("数据库等级: 良，成绩："+shujuku_Wsy);
        } else if (shujuku_Wsy>70&&shujuku_Wsy<80) {
            System.out.println("数据库等级: 中,成绩: "+shujuku_Wsy);
        } else if (shujuku_Wsy>60&&shujuku_Wsy<70) {
            System.out.println("数据库等级: 合格,成绩:"+shujuku_Wsy);
        }else {
            System.out.println("数据库等级：不及格，成绩："+shujuku_Wsy);
        }

        if (javal_Wsy>90){
            System.out.println("数据库等级: 优，成绩："+javal_Wsy);
        } else if(javal_Wsy>80&&javal_Wsy<90) {
            System.out.println("数据库等级: 良，成绩："+javal_Wsy);
        } else if (javal_Wsy>70&&javal_Wsy<80) {
            System.out.println("数据库等级: 中,成绩: "+javal_Wsy);
        } else if (javal_Wsy>60&&javal_Wsy<70) {
            System.out.println("数据库等级: 合格,成绩:"+javal_Wsy);
        }else {
            System.out.println("数据库等级：不及格，成绩："+javal_Wsy);
        }

        if (English_Wsy>90){
            System.out.println("数据库等级: 优，成绩："+English_Wsy);
        } else if(English_Wsy>80&&English_Wsy<90) {
            System.out.println("数据库等级: 良，成绩："+English_Wsy);
        } else if (English_Wsy>70&&English_Wsy<80) {
            System.out.println("数据库等级: 中,成绩: "+English_Wsy);
        } else if (English_Wsy>60&&English_Wsy<70) {
            System.out.println("数据库等级: 合格,成绩:"+English_Wsy);
        }else {
            System.out.println("数据库等级：不及格，成绩："+English_Wsy);
        }

        int avegreads_Wsy=0;
        avegreads_Wsy=(shujuku_Wsy+javal_Wsy+English_Wsy)/3;
        System.out.println("平均成绩:"+avegreads_Wsy);
    }


 void approximate_Wsy() {
        double ee_Wsy = 1.0;
        double ret_Wsy = 1.0;//阶乘
        double xx_Wsy = 0;//求1/n!
        for (int i = 1; i < 9999; i++) {
            ret_Wsy*= i;
            ee_Wsy += 1/ret_Wsy ;
            if (1/ret_Wsy < 1 / 10000) {
                break;
            }
        }
     System.out.println("近似值e："+ee_Wsy);
    }


    void formulaIf_WuSiYuan(double t,double y){
        if (t>=0&&t<1){
            y=t*t-1;
        } else if (t>=1&&t<3) {
            y=t*t*t-2*t-2;
        } else if (t>=3&&t<5) {
            double b=Math.sin(t);
            y=t*t-t*b;
        } else if (t>=5&&t<7) {
            y=t+1;
        }else {
            y=t-1;
        }
        System.out.println("Y的值:"+y);
    }

    void formulaSwitch_WuSiYuan(int tt_Wsy,double yy_Wsy){

        switch (tt_Wsy){
            case 0:
                yy_Wsy=tt_Wsy*tt_Wsy-1;
                System.out.println("Y的值:"+yy_Wsy);
                break;
            case 1:
                yy_Wsy=tt_Wsy*tt_Wsy*tt_Wsy-2*tt_Wsy-2;
                System.out.println("Y的值:"+yy_Wsy);
                break;
            case 2:
                yy_Wsy=tt_Wsy*tt_Wsy*tt_Wsy-2*tt_Wsy-2;
                System.out.println("Y的值:"+yy_Wsy);
                break;
            case 3:
               double ba=(double)tt_Wsy;
               double ma=Math.sin(ba);
               yy_Wsy=tt_Wsy*tt_Wsy-tt_Wsy*ma;
                System.out.println("Y的值:"+yy_Wsy);
                break;
            case 4:
                double aa_Wsy=(double)tt_Wsy;
                double ca_Wsy=Math.sin(aa_Wsy);
                yy_Wsy=tt_Wsy*tt_Wsy-tt_Wsy*ca_Wsy;
                System.out.println("Y的值:"+yy_Wsy);
                break;
            case 5:
                yy_Wsy=tt_Wsy+1;
                System.out.println("Y的值:"+yy_Wsy);
                break;
            case 6:
                yy_Wsy=tt_Wsy+1;
                System.out.println("Y的值:"+yy_Wsy);
                break;
            default:
                yy_Wsy=tt_Wsy-1;
                System.out.println("Y的值:"+yy_Wsy);
                break;
        }
    }
}
