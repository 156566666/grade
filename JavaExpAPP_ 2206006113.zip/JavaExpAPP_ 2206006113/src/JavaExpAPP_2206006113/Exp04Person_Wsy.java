package JavaExpAPP_2206006113;

public class Exp04Person_Wsy {
    String name_Wsy;
    char sex_Wsy;
    String birthday_Wsy;
    public Exp04Person_Wsy(){
}
    public Exp04Person_Wsy(String a_Wsy,char b_Wsy,String c_Wsy){
        name_Wsy=a_Wsy;
        sex_Wsy=b_Wsy;
        birthday_Wsy=c_Wsy;
    }

    void printInfo_Wsy(){
        System.out.println("名字:"+name_Wsy);
        System.out.println("性别:"+sex_Wsy);
        System.out.println("生日:"+birthday_Wsy);
    }
}
class Exp04Teacher_Wsy extends Exp04Person_Wsy{
    String schoolName_Wsy;
    String teacherId_Wsy;
    public Exp04Teacher_Wsy(String aa_Wsy,char bb_Wsy,String cc_Wsy,String a_Wsy,String b_Wsy){
        super(aa_Wsy,bb_Wsy,cc_Wsy);
        schoolName_Wsy=a_Wsy;
        teacherId_Wsy=b_Wsy;
    }
    void printInfo_Wsy(){
        super.printInfo_Wsy();
        System.out.println("学校:"+schoolName_Wsy);
        System.out.println("工号:"+teacherId_Wsy);
    }
}
class Exp04Student_Wsy extends Exp04Person_Wsy{
    String studentId_Wsy;
    String major_Wsy;
    int grade_Wsy;
    int clas_Wsy;
    public Exp04Student_Wsy(String aa_Wsy,char bb_Wsy,String cc_Wsy,String a_Wsy,String b_Wsy,int c_Wsy,int d_Wsy){
        super(aa_Wsy,bb_Wsy,cc_Wsy);
        studentId_Wsy=a_Wsy;
        major_Wsy=b_Wsy;
        grade_Wsy=c_Wsy;
        clas_Wsy=d_Wsy;
    }

    @Override
    void printInfo_Wsy() {
        super.printInfo_Wsy();
        System.out.println("学号:"+studentId_Wsy);
        System.out.println("专业:"+major_Wsy);
        System.out.println("年级:"+grade_Wsy);
        System.out.println("班级"+clas_Wsy);
    }
}
