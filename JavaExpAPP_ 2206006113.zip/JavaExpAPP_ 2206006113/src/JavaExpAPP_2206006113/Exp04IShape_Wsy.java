package JavaExpAPP_2206006113;

public interface Exp04IShape_Wsy {


    void area_Wsy();

    void perimeter_Wsy();
}

class Exp04Circle_Wsy implements Exp04IShape_Wsy {

    int r_Wsy;

    public Exp04Circle_Wsy(int r_Wsy) {
        this.r_Wsy = r_Wsy;
    }

    @Override
    public void area_Wsy() {

        double area_Wsy;
        area_Wsy = Math.PI * r_Wsy * r_Wsy;
        System.out.println("该圆形的面积是:" + area_Wsy);
    }

    @Override
    public void perimeter_Wsy() {
        double perimeter_Wsy;
        perimeter_Wsy = 2 * Math.PI * r_Wsy;
        System.out.println("该圆形的周长是:" + perimeter_Wsy);

    }
}

class Exp04Square_Wsy implements Exp04IShape_Wsy {
    int width_Wsy;
    int length_Wsy;

    public Exp04Square_Wsy(int width_Wsy, int length_Wsy) {
        this.width_Wsy = width_Wsy;
        this.length_Wsy = length_Wsy;
    }

    @Override
    public void area_Wsy() {
        double area_Wsy;
        area_Wsy = width_Wsy * length_Wsy;
        System.out.println("该矩形的面积是:" + area_Wsy);

    }

    @Override
    public void perimeter_Wsy() {
        double perimeter_Wsy;
        perimeter_Wsy = 2 * (width_Wsy + length_Wsy);
        System.out.println("该矩形的周长是:" + perimeter_Wsy);
    }
}


class Exp04Triangle_Wsy implements Exp04IShape_Wsy {
    int a_Wsy;
    int b_Wsy;
    int c_Wsy;

    public Exp04Triangle_Wsy(int a_Wsy, int b_Wsy, int c_Wsy) {
        this.a_Wsy = a_Wsy;
        this.b_Wsy = b_Wsy;
        this.c_Wsy = c_Wsy;
    }

    @Override
    public void area_Wsy() {
        double area_Wsy;
        double p_Wsy = (1 / 2.0) * (a_Wsy + b_Wsy + c_Wsy);
        area_Wsy = Math.sqrt(p_Wsy * (p_Wsy - a_Wsy) * (p_Wsy - b_Wsy) * (p_Wsy - c_Wsy));
        System.out.println("该三角形的面积是:" + area_Wsy);
    }

    @Override
    public void perimeter_Wsy() {

        double perimeter_Wsy;
        perimeter_Wsy = a_Wsy + b_Wsy + c_Wsy;
        System.out.println("该三角形的周长是:" + perimeter_Wsy);
    }
}