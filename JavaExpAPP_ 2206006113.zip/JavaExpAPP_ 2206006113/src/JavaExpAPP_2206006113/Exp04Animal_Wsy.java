package JavaExpAPP_2206006113;

public class Exp04Animal_Wsy {
    String animalName_Wsy;
    public Exp04Animal_Wsy(){

    }
    public Exp04Animal_Wsy(String a_Wsy){
        animalName_Wsy=a_Wsy;
    }
    void shout_Wsy(){//动物叫声
        System.out.println(animalName_Wsy+"发出叫声");
    }
}
class Exp04Cat_Wsy extends Exp04Animal_Wsy{
    public Exp04Cat_Wsy(String catName_Wsy){

        super(catName_Wsy);
    }
}
