package JavaExpAPP_2206006113;

import java.util.*;

public class Exp06_Wsy {
    public static void main(String[] args) {
        Exp06_Wsy test_Wsy=new Exp06_Wsy();
        test_Wsy.menu_Wsy();
    }
    void  menu_Wsy(){
        while(true) {
            System.out.println("请选择你的项目:");
            System.out.println("0:退出选择");
            System.out.println("1:数英翻译系统（智能板）");
            System.out.println("2:数组相除");
            System.out.println("3:学生成绩");
            System.out.println("4:学生学号");
            Scanner SC_Wsy = new Scanner(System.in);
            int choice_Wsy = SC_Wsy.nextInt();
            switch (choice_Wsy) {
                case 0:
                    return;
                case 1:


                    break;

                case 2:
                    arrayDivide_Wsy();
                    break;

                case 3:

                    stuGrade_Wsy();
                    break;

                case 4:
                    stuNumber_Wsy();
                    break;

            }
        }
    }


    void translate_Wsy(){


    }

    void arrayDivide_Wsy() {

        int[] arr1_Wsy;
        int[] arr2_Wsy;

        int N1_Wsy;
        int N2_Wsy;

        Scanner Array_Wsy = new Scanner(System.in);
        System.out.println("请输入N1，N2，并确保N1>N2");

        System.out.println("请为数组array1确定长度N1（>9）：");
        N1_Wsy = Array_Wsy.nextInt();

        System.out.println("请为数组array2确定长度N2（>9）：");
        N2_Wsy = Array_Wsy.nextInt();

        arr1_Wsy = new int[N1_Wsy];
        arr2_Wsy = new int[N2_Wsy];

        Random random_Wsy = new Random();//0-100
        //为array1初始化
        for (int i_Wsy = 0; i_Wsy < N1_Wsy; i_Wsy++) {
            arr1_Wsy[i_Wsy] = random_Wsy.nextInt(100) + 1;
        }

        //为array2初始化
        int randomposition1_Wsy = random_Wsy.nextInt(N2_Wsy );//第一个0的位置
        int randomposition2_Wsy = random_Wsy.nextInt(N2_Wsy );//第二个0的位置
        while (randomposition2_Wsy == randomposition1_Wsy - 1 || randomposition2_Wsy == randomposition1_Wsy + 1 || randomposition2_Wsy == randomposition1_Wsy) {
            randomposition2_Wsy = random_Wsy.nextInt(N2_Wsy);
        }
//保留随机位置
        int count1_Wsy=randomposition1_Wsy;
        int count2_Wsy=randomposition2_Wsy;

        arr2_Wsy[count1_Wsy] = 0;
        arr2_Wsy[count2_Wsy] = 0;

        for (int j_Wsy = 0; j_Wsy < N2_Wsy; j_Wsy++) {
            if(j_Wsy==count1_Wsy||j_Wsy==count2_Wsy) {
                continue;
            }else {
                arr2_Wsy[j_Wsy]=random_Wsy.nextInt(100)+1;
            }
        }


        //打印检查是否错误
        System.out.println("array1:");
        for (int i_Wsy = 0; i_Wsy < N1_Wsy; i_Wsy++) {
            System.out.println(arr1_Wsy[i_Wsy]);
        }
        System.out.println("array2：");
        for (int j_Wsy = 0; j_Wsy < N2_Wsy; j_Wsy++) {
            System.out.println(arr2_Wsy[j_Wsy]);
        }

        //开始除法
        System.out.println("检查除法错误:");
        for (int i_Wsy = 0; i_Wsy<N1_Wsy ; i_Wsy++) {
            double[] arr3_Wsy = new double[N1_Wsy];
            try {
                System.out.println(arr1_Wsy[i_Wsy]+"/"+arr2_Wsy[i_Wsy]+"="+(arr3_Wsy[i_Wsy] = arr1_Wsy[i_Wsy]/ arr2_Wsy[i_Wsy]));
            } catch (ArrayIndexOutOfBoundsException e1_Wsy) {
                e1_Wsy.printStackTrace();
                System.out.println("数组越界");
            } catch (ArithmeticException e2_Wsy) {
                e2_Wsy.printStackTrace();
                System.out.println("不能除0");
            }
        }
    }

    void stuGrade_Wsy(){
        int [] Grade_Wsy = new int[10];

        try {
            System.out.println("请输入十个数作为学生的成绩,每个成绩直接用空格分隔开:");

            Scanner grade_Wsy = new Scanner(System.in);
            String g_Wsy=grade_Wsy.nextLine();
            String[] grades_Wsy=g_Wsy.split("");//字符串存为字符数组

            for (int i_Wsy = 0; i_Wsy < 10; i_Wsy++) {
                Grade_Wsy[i_Wsy]=Integer.parseInt(grades_Wsy[i_Wsy]);//字符数组转为Int
            }

        }catch (NumberFormatException e1_Wsy){//不为整数，为浮点数，字符串

            e1_Wsy.printStackTrace();
            System.out.println("输入成绩不为整数!!!!!!!!");

        }catch (ArrayIndexOutOfBoundsException e2_Wsy){//不足十个

            e2_Wsy.printStackTrace();
            System.out.println("请输入十个成绩!!!!!!");

        }finally {

            Arrays.sort(Grade_Wsy);//利用Collections的reverseOrder降序排列，不能使用int char等基本类型
            System.out.println("成绩排序后:");//默认升序排列
            for (int min_Wsy = 0, max_Wsy = Grade_Wsy.length - 1; min_Wsy <= max_Wsy; min_Wsy++, max_Wsy--) {
                int temp = Grade_Wsy[min_Wsy];
                Grade_Wsy[min_Wsy] = Grade_Wsy[max_Wsy];
                Grade_Wsy[max_Wsy] = temp;
            }//最小位换到最大位

            for (int i_Wsy = 0; i_Wsy < Grade_Wsy.length; i_Wsy++) {
                System.out.print(Grade_Wsy[i_Wsy]+" ");
            }
            System.out.println();
            System.out.println("0为没有输入的成绩");
            System.out.println();

        }



    }


    void stuNumber_Wsy(){
                                              //  年级      学院           专业  班级          班内学号
        int[] stuNum_Wsy=new int[10];//存储学号例如‘2’‘2’   ‘0’‘6’    ‘0’   ‘0’  ‘6’    ‘1’   ‘1’‘3’
                                               //0  1     2  3      4     5    6      7     8  9
        try {
            System.out.println("请输入您的学号:");

            Scanner SA_Wsy = new Scanner(System.in);
            String input_Wsy = SA_Wsy.nextLine();

            String[] stunum_Wsy = input_Wsy.split("");//将输入的字符串按个位存储起来

            for (int i_Wsy = 0; i_Wsy < 10; i_Wsy++) {
                stuNum_Wsy[i_Wsy] = Integer.parseInt(stunum_Wsy[i_Wsy]);//字符串类型的数组转换成int型数字
            }

           checkExcep_Wsy(stuNum_Wsy);

            System.out.println("您的学号无误");
            System.out.println();


            if (stuNum_Wsy[0]==1){
                System.out.println("您的年级是:"+1+stuNum_Wsy[1]+"级");
            }else if (stuNum_Wsy[0]==2&&stuNum_Wsy[1]<4){
                System.out.println("您的年级是:"+2+stuNum_Wsy[1]+"级");
            }

            if (stuNum_Wsy[3]==6){
                System.out.println("您的学院是计算机工程学院!");
            }

            if (stuNum_Wsy[5]==0){
                System.out.println("您的专业是物联网工程和数字媒体技术,班级是:"+stuNum_Wsy[6]+"班");
            } else if (stuNum_Wsy[5]==1) {
                System.out.println("您的专业是计算机科学与计算和软件工程，班级是:"+stuNum_Wsy[6]+"班");
            }

            System.out.println("您在班级的学号是:"+stuNum_Wsy[8]+stuNum_Wsy[9]);


        }catch (ArrayIndexOutOfBoundsException e1_Wsy){//学号不足10位

            System.out.println("学号不足十位");

        }catch (MyException_Wsy e2_Wsy){
            System.out.println("错误:"+e2_Wsy);
        }finally {
            return;
        }





    }
    public  static void checkExcep_Wsy (int[] a_Wsy) throws MyException_Wsy{


        if (a_Wsy[1]>3){
            throw new MyException_Wsy("年级不能超过2023级！！");
        } else if (a_Wsy[3]!=6) {
            throw new MyException_Wsy("学院应该是计算机工程学院！！！");
        } else if (a_Wsy[5]!=0&&a_Wsy[5]!=1) {
            throw new MyException_Wsy("专业错误！！！");
        } else if ((a_Wsy[6]>6&&a_Wsy[5]==0)||(a_Wsy[5]==1&&a_Wsy[6]>4)) {
            throw new MyException_Wsy("班级数有误");
        }
    }


}

class MyException_Wsy extends Exception{//撰写异常类
    public  MyException_Wsy(){

    }
    public MyException_Wsy(String message_Wsy){
        super(message_Wsy);
    }

}


