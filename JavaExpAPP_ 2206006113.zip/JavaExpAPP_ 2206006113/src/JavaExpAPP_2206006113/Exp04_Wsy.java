package JavaExpAPP_2206006113;

import java.util.Scanner;

public class Exp04_Wsy {
    void menu_Wsy(){

        while(true){
            System.out.println("请选择你的项目:");
            System.out.println("0:退出选择");
            System.out.println("1:Animal");
            System.out.println("2:Person");
            System.out.println("3:IShape");
            Scanner SC_Wsy=new Scanner(System.in);
            int choice_Wsy=SC_Wsy.nextInt();
            switch (choice_Wsy){
                case 0:

                    return;

                case 1:
                    testAnimal_Wsy();
                    break;

                case 2:
                    testPerson();
                    break;

                case 3:
                    testShape_Wsy();
                    break;


            }
        }
    }

    void testAnimal_Wsy(){
        String name_Wsy="波斯猫";
        Exp04Cat_Wsy e4_Wsy=new Exp04Cat_Wsy(name_Wsy);
        e4_Wsy.shout_Wsy();
    }


    void testPerson(){
        Exp04Student_Wsy s_Wsy=new Exp04Student_Wsy("江玟",'男',"2004 4 28","2206006121","计算机科学与技术",2022,2206013);
        Exp04Teacher_Wsy t_Wsy=new Exp04Teacher_Wsy("吴思源",'男',"2003 09 24","北京大学","2206006113");
        System.out.println("学生信息:");
        s_Wsy.printInfo_Wsy();
        System.out.println("老师信息:");
        t_Wsy.printInfo_Wsy();
    }


    void testShape_Wsy(){
        Exp04IShape_Wsy[] shape_Wsy=new Exp04IShape_Wsy[3];

        shape_Wsy[0]=new Exp04Circle_Wsy(3);//初始化r
        shape_Wsy[1]=new Exp04Square_Wsy(3,4);//初始化长宽
        shape_Wsy[2]=new Exp04Triangle_Wsy(3,4,5);//初始化三边

        for (int i_Wsy = 0; i_Wsy < 3; i_Wsy++) {
            shape_Wsy[i_Wsy].area_Wsy();
            shape_Wsy[i_Wsy].perimeter_Wsy();
        }


    }
}
