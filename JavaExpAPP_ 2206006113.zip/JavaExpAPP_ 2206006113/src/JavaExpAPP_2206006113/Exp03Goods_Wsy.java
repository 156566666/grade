package JavaExpAPP_2206006113;

 public class Exp03Goods_Wsy {
    int GoodsNum_Wsy;
    String GoodsName_Wsy;
    int GoodsCount_Wsy;

}
