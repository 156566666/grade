package JavaExpAPP_2206006113;

import java.util.Scanner;

public class Exp02_Wsy {
    public class Exp02Rectangle_Wsy{
        int length_Wsy;
        int width_Wsy;
        int area_Wsy;
        int Perimeter_Wsy;
        public Exp02Rectangle_Wsy(){
            //
        }
        public Exp02Rectangle_Wsy(int aa_Wsy,int bb_Wsy){
            length_Wsy=bb_Wsy;
            width_Wsy=aa_Wsy;
        }
        public int getPerimeter_Wsy() {
            Perimeter_Wsy=(length_Wsy+width_Wsy)*2;
            return Perimeter_Wsy;
        }

        public int getArea_Wsy() {
            area_Wsy=length_Wsy*width_Wsy;
            return area_Wsy;
        }

        public  void draw_Wsy(){
            for (int i_Wsy = 1; i_Wsy<=width_Wsy ; i_Wsy++) {
                for (int j_Wsy = 1; j_Wsy <=length_Wsy ; j_Wsy++) {
                    if(i_Wsy==1||i_Wsy==width_Wsy){
                        System.out.print("*"+" ");
                        if(j_Wsy==length_Wsy){
                            System.out.println();
                        }
                    } else if (j_Wsy==1||j_Wsy==length_Wsy) {
                        System.out.print("*"+" ");
                        if(j_Wsy==length_Wsy){
                            System.out.println();
                        }
                    } else {
                        System.out.print("  ");
                    }

                }
            }
        }
    }
    public class Exp02Triangle_Wsy{
        int aa_Wsy;
        int bb_Wsy;
        int cc_Wsy;

         public void creat_Wsy(){
             System.out.println("输入三个小于30的实数：");
             Scanner AA_Wsy=new Scanner(System.in);
             int a_Wsy= AA_Wsy.nextInt();
             int b_Wsy= AA_Wsy.nextInt();
             int c_Wsy= AA_Wsy.nextInt();
             int p_Wsy=0;
             double area_Wsy=0;
             if(a_Wsy+b_Wsy<c_Wsy||a_Wsy+c_Wsy<b_Wsy||b_Wsy+c_Wsy<a_Wsy){
                 int min_Wsy=0;
                 if(a_Wsy<b_Wsy){
                     min_Wsy=a_Wsy;
                     if(c_Wsy<a_Wsy){
                         min_Wsy=c_Wsy;
                     }
                 }
                 System.out.println("该三角形是以"+min_Wsy+"为边的等边三角形");
                 a_Wsy=b_Wsy=c_Wsy=min_Wsy;
                 p_Wsy=(1/2)*(a_Wsy+b_Wsy+c_Wsy);
                 area_Wsy=Math.sqrt(p_Wsy*(p_Wsy-a_Wsy)*(p_Wsy-b_Wsy)*(p_Wsy-c_Wsy));
                 System.out.println("面积是："+area_Wsy);
             }
             else {
                 System.out.println("该三角形是以"+a_Wsy+" "+b_Wsy+" "+c_Wsy+" "+"为三边的三角形");
                 p_Wsy=(1/2)*(a_Wsy+b_Wsy+c_Wsy);
                 area_Wsy=Math.sqrt(p_Wsy*(p_Wsy-a_Wsy)*(p_Wsy-b_Wsy)*(p_Wsy-c_Wsy));
                 System.out.println("面积是:"+area_Wsy);
             }
        }
    }

    public class Exp02Point_Wsy{
        int x_Wsy;
        int y_Wsy;
        public  Exp02Point_Wsy(){
           x_Wsy=0;
           y_Wsy=0;
        }
        public Exp02Point_Wsy(int x_Wsy,int y_Wsy){
            this.x_Wsy=x_Wsy;
            this.y_Wsy=y_Wsy;
        }

    }



    public static void main(String[] args) {
        //**********************************
        //Exp02_Wsy AA1_Wsy=new Exp02_Wsy();
        //AA1_Wsy.rectangleExec_Wsy();
        //Exp02ScoreManage_Wsy  ScoreManage_Wsy =new Exp02ScoreManage_Wsy();
        //ScoreManage_Wsy.scoreManageExec_Wsy();
    }
    public void menu_Wsy(){
        System.out.println("请选择：");
        System.out.println("1:矩形");
        System.out.println("2:三角形");
        System.out.println("3:二维平面的点");
        System.out.println("4:成绩管理系统");
        Scanner sc_Wsy=new Scanner(System.in);
        int choice_Wsy= sc_Wsy.nextInt();
        switch (choice_Wsy){
            case 1:
                rectangleExec_Wsy();
                break;
            case 2:
                triangleExec_Wsy();
                break;
            case 3:
                pointExec_Wsy();
                break;
            case 4:
                Exp02ScoreManage_Wsy  ScoreManage_Wsy =new Exp02ScoreManage_Wsy();
                ScoreManage_Wsy.scoreManageExec_Wsy();
                break;
        }


    }

    public void rectangleExec_Wsy(){
        Exp02Rectangle_Wsy A1_Wsy=new Exp02Rectangle_Wsy(3,4);
        A1_Wsy.draw_Wsy();
    }

    public  void triangleExec_Wsy(){
        Exp02Triangle_Wsy A2_Wsy=new Exp02Triangle_Wsy();
        A2_Wsy.creat_Wsy();
    }

    public void distance_Wsy(Exp02Point_Wsy x1_Wsy,Exp02Point_Wsy x2_Wsy){
        double xxx1_Wsy=0;
        double yyy1_Wsy=0;
        double distance1_Wsy=0;
        xxx1_Wsy=(x2_Wsy.x_Wsy-x1_Wsy.y_Wsy);
        yyy1_Wsy=x2_Wsy.y_Wsy-x1_Wsy.y_Wsy;
        distance1_Wsy=Math.sqrt(xxx1_Wsy*xxx1_Wsy-yyy1_Wsy*yyy1_Wsy);
        System.out.println("(1,1)到点（3，3）的距离是"+distance1_Wsy);

    }
    public  void pointExec_Wsy(){
        Exp02Point_Wsy xx1_Wsy=new Exp02Point_Wsy(1,1);
        Exp02Point_Wsy xx2_Wsy=new Exp02Point_Wsy(3,3);
        distance_Wsy(xx1_Wsy,xx2_Wsy);
    }
}
