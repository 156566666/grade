package JavaExpAPP_2206006113;

import java.util.Scanner;

public class Exp03BuyGoods_Wsy extends Exp03Goods_Wsy{
    //录入进货信息，显示进货情况

    public static void main(String[] args) {
        Exp03BuyGoods_Wsy a1_Wsy=new Exp03BuyGoods_Wsy();
        a1_Wsy.getGoods_Wsy();
        a1_Wsy.showGoods_Wsy();
    }


    void getGoods_Wsy() {
        System.out.println("请输入你想进货多少种东西:");
        Scanner SX = new Scanner(System.in);
         int goods_Wsy = SX.nextInt();

        //创建与用户输入种类数量相等的Exp03Goods_Wsy数组
        //Exp03Goods_Wsy[] Goods_Wsy = new Exp03Goods_Wsy[goods_Wsy];

        //初始化大小
        Exp03_Wsy.Goods_Wsy = new Exp03Goods_Wsy[goods_Wsy];

        System.out.println("请输入你进货的信息:");
        for (int j_Wsy = 0; j_Wsy < goods_Wsy; j_Wsy++) {

            System.out.println("第" + (j_Wsy + 1) + "个货物的编号");
            int id_Wsy = SX.nextInt();
            SX.nextLine();

            System.out.println("第" + (j_Wsy + 1) + "个货物的名字");
            String nm_Wsy = SX.nextLine();

            System.out.println("第" + (j_Wsy + 1) + "个货物的数量");
            int c_Wsy = SX.nextInt();
            SX.nextLine();

            // 初始化当前数组元素（假设Exp03Goods_Wsy有默认构造函数）
            Exp03_Wsy.Goods_Wsy[j_Wsy] = new Exp03Goods_Wsy();
            Exp03_Wsy.Goods_Wsy[j_Wsy].GoodsNum_Wsy = id_Wsy;
            Exp03_Wsy.Goods_Wsy[j_Wsy].GoodsName_Wsy = nm_Wsy;
            Exp03_Wsy.Goods_Wsy[j_Wsy].GoodsCount_Wsy = c_Wsy;
        }
    }

    void showGoods_Wsy() {
        System.out.println("显示您的进货信息:");

        for (int i_Wsy = 0; i_Wsy < Exp03_Wsy.Goods_Wsy.length; i_Wsy++) {
            Exp03Goods_Wsy currentGood = Exp03_Wsy.Goods_Wsy[i_Wsy];

            System.out.println("货物编号: " + currentGood.GoodsNum_Wsy);
            System.out.println("货物名称: " + currentGood.GoodsName_Wsy);
            System.out.println("货物数量: " + currentGood.GoodsCount_Wsy);
            System.out.println("------------------------");
        }
    }
}
